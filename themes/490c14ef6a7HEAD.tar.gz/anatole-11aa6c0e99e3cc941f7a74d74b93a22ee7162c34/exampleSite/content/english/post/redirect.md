+++
author = "Hugo Authors"
title = "Redirect"
date = "2021-06-20"
description = "Usage of redirectUrl"
tags = [
    "redirect", "redirectUrl",
]
redirectUrl="https://gohugo.io"
+++

Forwarding to [gohugo](https://gohugo.io) using `redirectUrl`

{{% loading %}}
