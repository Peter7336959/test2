+++
title = "Certifications"
description = "Hugo Certifications"
date = "2022-04-10"
aliases = ["certifications"]
author = "Hugo Authors"
+++

## 3 Best Hugo Courses, Training, Classes & Tutorials Online

1. “Migrate from WordPress to Hugo, Step by Step” Our Best Pick 2022
2. Create a Static Site With Hugo 2021
3. Créez votre site statique avec Hugo 2020
